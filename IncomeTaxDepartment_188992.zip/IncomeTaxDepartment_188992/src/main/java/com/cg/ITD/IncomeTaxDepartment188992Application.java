package com.cg.ITD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IncomeTaxDepartment188992Application {

	public static void main(String[] args) {
		SpringApplication.run(IncomeTaxDepartment188992Application.class, args);
	}

}
