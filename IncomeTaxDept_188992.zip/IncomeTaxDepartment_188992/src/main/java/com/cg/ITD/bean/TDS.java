package com.cg.ITD.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "tdsdetail")
public class TDS {

	@Id
	private int id;
	private String deductor_name;
	private String deductor_pan;
	private String tds_deposited;

	public TDS() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TDS(int id, String deductor_name, String deductor_pan, String tds_deposited) {
		super();
		this.id = id;
		this.deductor_name = deductor_name;
		this.deductor_pan = deductor_pan;
		this.tds_deposited = tds_deposited;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDeductor_name() {
		return deductor_name;
	}

	public void setDeductor_name(String deductor_name) {
		this.deductor_name = deductor_name;
	}

	public String getDeductor_pan() {
		return deductor_pan;
	}

	public void setDeductor_pan(String deductor_pan) {
		this.deductor_pan = deductor_pan;
	}

	public String getTds_deposited() {
		return tds_deposited;
	}

	public void setTds_deposited(String tds_deposited) {
		this.tds_deposited = tds_deposited;
	}

	@Override
	public String toString() {
		return "TDS [id=" + id + ", deductor_name=" + deductor_name + ", deductor_pan=" + deductor_pan
				+ ", tds_deposited=" + tds_deposited + "]";
	}

}
