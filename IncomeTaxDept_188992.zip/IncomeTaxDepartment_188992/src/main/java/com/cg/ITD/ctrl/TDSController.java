package com.cg.ITD.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ITD.bean.TDS;
import com.cg.ITD.exception.TDSException;
import com.cg.ITD.service.ITDService;



@RestController
@RequestMapping("/user")
public class TDSController {

	@Autowired
	ITDService ItdSer;

	@GetMapping(value = "/tds/{id}")
	public TDS getById(@PathVariable("id") int id) throws TDSException {
		TDS detail = ItdSer.findById(id).get();
		if (detail == null) {
			throw new TDSException("ID Not found Wrong ID :" + id);
		} else {
			return detail;
		}

	}

}
