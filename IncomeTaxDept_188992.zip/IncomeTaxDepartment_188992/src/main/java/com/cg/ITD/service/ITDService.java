package com.cg.ITD.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ITD.bean.TDS;
import com.cg.ITD.dao.TDSDao;

@Service
@Transactional
public class ITDService implements ITDServiceImpl {

	@Autowired
	TDSDao tdsdao;

	public Optional<TDS> findById(int id) {
		return tdsdao.findById(id);
	}

}
