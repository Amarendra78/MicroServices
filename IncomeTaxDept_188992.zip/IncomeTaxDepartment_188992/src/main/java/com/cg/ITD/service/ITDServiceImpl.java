package com.cg.ITD.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.ITD.bean.TDS;

@Service
public interface ITDServiceImpl {

	public Optional<TDS> findById(int id);
}
