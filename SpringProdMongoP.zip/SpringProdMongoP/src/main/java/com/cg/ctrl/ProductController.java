package com.cg.ctrl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;

@RestController
@RequestMapping("/proddemo")
public class ProductController {
	
	@Autowired ProductDao proDao;
	
	@PostMapping(value="/create/",consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public Product createProd(@RequestBody Product prod)
	{
		return proDao.save(prod);
		
		/*return("Data inserted");*/
	}

	
	@GetMapping(value="/fetchAllProd",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Product> fetchAllProd()
	{
		return proDao.findAll();
		
	}
	
	
	@DeleteMapping(value="/deleteProduct/{pid}")
	public String deleteProductById(@PathVariable("pid")String prodId)
	{
		proDao.deleteById(prodId);
		return "data is deleted";
	}
	
	@PutMapping(value="/update/{pid}",consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProd(@PathVariable("pid")String prodId,@RequestBody Product prod)
	{
		prod.setId(prodId);
		proDao.save(prod);
		return("Data updated");
	}
	
}
