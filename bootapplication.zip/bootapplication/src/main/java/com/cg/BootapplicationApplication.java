package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@SpringBootApplication
public class BootapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootapplicationApplication.class, args);
		System.out.println("Rest Controller started...");
	}

}
